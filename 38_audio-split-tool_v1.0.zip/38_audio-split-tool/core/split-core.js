/* split-core.js — 音声の区間計算（画面にもファイルにも依存しない）
 * 式は、本体のツール（src/lib.js の buildSegments）と同じ：
 *   区間の数 = ceil(全長 ÷ 分割単位 − 1e-6)
 *   開始 = i × 分割単位、長さ = min(分割単位, 全長 − 開始)
 * ブラウザでは window.AudioSplitCore、Node.js では require で使う。 */
(function (root) {
  "use strict";

  // MB は 10 の 6 乗バイト（この本の計算と同じ。25 MB = 25,000,000 バイト）
  const MB = 1000 * 1000;

  /** 区間の一覧。不正な値は空配列（区間を作らない） */
  function segments(durationSec, segSec) {
    if (!Number.isFinite(durationSec) || !Number.isFinite(segSec)) return [];
    if (durationSec <= 0 || segSec <= 0) return [];
    const total = Math.ceil(durationSec / segSec - 1e-6);
    const out = [];
    for (let i = 0; i < total; i++) {
      const offset = i * segSec;
      out.push({ index: i, offset, duration: Math.min(segSec, durationSec - offset), total });
    }
    return out;
  }

  /** 秒を hh:mm:ss（小数は切り捨て）にする */
  function fmtTime(sec) {
    const s = Math.floor(Number.isFinite(sec) && sec > 0 && sec < 1e9 ? sec : 0);
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60;
    const p = (n) => String(n).padStart(2, "0");
    return `${p(h)}:${p(m)}:${p(r)}`;
  }

  /** 見出し（区間の時刻を、読みやすく） */
  function label(seg) {
    return `第${seg.index + 1}部（${fmtTime(seg.offset)}〜${fmtTime(seg.offset + seg.duration)}）`;
  }

  /** PCM の WAV の大きさ（バイト）。ヘッダー44バイトを含む */
  function wavBytes(durationSec, rate, channels, bits) {
    if (!(durationSec >= 0) || !(rate > 0) || !(channels > 0) || !(bits > 0)) return NaN;
    return 44 + Math.round(durationSec * rate * channels * (bits / 8));
  }

  /** 上限（MB）に入る、WAV の最長の秒数 */
  function maxSecondsForLimit(limitMB, rate, channels, bits) {
    const per = wavBytes(1, rate, channels, bits) - 44;
    if (!(limitMB > 0) || !(per > 0)) return NaN;
    return Math.floor((limitMB * MB - 44) / per);
  }

  /** 画面の表示や、報告に使う、分かりやすい大きさ（MB は 10 の 6 乗バイト） */
  function fmtMB(bytes) { return (bytes / MB).toFixed(1) + " MB"; }

  /** 送り先ごとの目安（決め打ちではなく、変えられる値）。出典は README を参照 */
  const PROFILES = {
    whisper16k: { name: "Whisper形式（16kHz・モノラル・16bit WAV、上限25MB）", rate: 16000, channels: 1, bits: 16, limitMB: 25 },
    azure16k:   { name: "Azure版（16kHz・モノラル・16bit WAV、区間は最大60分）", rate: 16000, channels: 1, bits: 16, maxSegMinutes: 60 },
  };

  const api = { MB, segments, fmtTime, label, wavBytes, maxSecondsForLimit, fmtMB, PROFILES };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.AudioSplitCore = api;
})(typeof window !== "undefined" ? window : globalThis);
