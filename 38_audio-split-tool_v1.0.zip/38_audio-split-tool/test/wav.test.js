const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const W = require("../cli/wav-split.js");

// 試験用の WAV（16kHz・モノラル・16bit）。振幅は、位置で決まる規則的な値
function makeWav(file, seconds, rate = 16000) {
  const frames = seconds * rate;
  const data = Buffer.alloc(frames * 2);
  for (let i = 0; i < frames; i++) data.writeInt16LE((i * 37) % 30000, i * 2);
  const fmt = { format: 1, channels: 1, rate, blockAlign: 2, bits: 16 };
  fs.writeFileSync(file, Buffer.concat([W.header(data.length, fmt), data]));
  return data;
}

test("W-01 splitWavFile：5秒を2秒ごとに分けると、2秒・2秒・1秒の3ファイルになる", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "wav-"));
  const input = path.join(dir, "in.wav");
  makeWav(input, 5);
  const outs = W.splitWavFile(input, path.join(dir, "out"), 2);
  assert.equal(outs.length, 3);
  assert.deepEqual(outs.map((o) => Math.round(o.seconds * 10) / 10), [2, 2, 1]);
});

test("W-02 分けたものを合わせると、元の音声と同じ（欠けも、重なりもない）", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "wav-"));
  const input = path.join(dir, "in.wav");
  const original = makeWav(input, 7);
  const outs = W.splitWavFile(input, path.join(dir, "out"), 3);
  const parts = outs.map((o) => W.readWav(fs.readFileSync(o.file)).data);
  assert.ok(Buffer.concat(parts).equals(original), "分けた音声を合わせた中身が、元と一致しない");
});

test("W-03 分けたファイルの形式は、元と同じ（周波数、チャンネル、16bit）", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "wav-"));
  const input = path.join(dir, "in.wav");
  makeWav(input, 3);
  const outs = W.splitWavFile(input, path.join(dir, "out"), 1);
  const { fmt } = W.readWav(fs.readFileSync(outs[0].file));
  assert.deepEqual([fmt.rate, fmt.channels, fmt.bits], [16000, 1, 16]);
});

test("W-04 PCM 以外や、WAV でないファイルは、理由を出して止める", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "wav-"));
  const txt = path.join(dir, "memo.txt"); fs.writeFileSync(txt, "hello");
  assert.throws(() => W.readWav(fs.readFileSync(txt)), /WAV ファイルではありません/);
  // 形式コード 3（浮動小数点）の WAV は、この道具では扱わない
  const data = Buffer.alloc(64);
  const h = W.header(data.length, { format: 1, channels: 1, rate: 16000, blockAlign: 2, bits: 16 });
  h.writeUInt16LE(3, 20);
  assert.throws(() => W.readWav(Buffer.concat([h, data])), /PCM（形式 1）ではありません/);
});
