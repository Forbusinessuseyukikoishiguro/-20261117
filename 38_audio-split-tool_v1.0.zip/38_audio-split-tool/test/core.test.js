const test = require("node:test");
const assert = require("node:assert/strict");
const C = require("../core/split-core.js");

test("S-01 segments：割り切れる場合は、区間の数と長さが正しい", () => {
  const s = C.segments(1200, 600);
  assert.equal(s.length, 2);
  assert.deepEqual(s.map((x) => x.duration), [600, 600]);
  assert.deepEqual(s.map((x) => x.offset), [0, 600]);
});

test("S-02 segments：端数の区間は、残りの長さになる（3725 ÷ 600 → 7区間、最後は125秒）", () => {
  const s = C.segments(3725, 600);
  assert.equal(s.length, 7);
  assert.equal(s[6].offset, 3600);
  assert.equal(s[6].duration, 125);
});

test("S-03 segments：浮動小数点の誤差で、余分な区間を作らない（BUG-01 の対策）", () => {
  assert.equal(C.segments(600.0000000000001, 600).length, 1);
});

test("S-04 segments：不正な値は、区間を作らない", () => {
  assert.deepEqual(C.segments(0, 600), []);
  assert.deepEqual(C.segments(600, 0), []);
  assert.deepEqual(C.segments(NaN, 600), []);
  assert.deepEqual(C.segments(-1, 600), []);
});

test("S-05 segments の性質：区間の長さの合計は、必ず全長と一致する（乱数 500 件）", () => {
  let seed = 12345; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
  for (let k = 0; k < 500; k++) {
    const total = 1 + Math.floor(rnd() * 20000);
    const seg = 1 + Math.floor(rnd() * 900);
    const sum = C.segments(total, seg).reduce((a, x) => a + x.duration, 0);
    assert.ok(Math.abs(sum - total) < 1e-6, `全長 ${total}、分割 ${seg} で合計が ${sum}`);
  }
});

test("S-06 fmtTime：秒を hh:mm:ss にする。小数は切り捨て", () => {
  assert.equal(C.fmtTime(3725), "01:02:05");
  assert.equal(C.fmtTime(59.9), "00:00:59");
  assert.equal(C.fmtTime(-5), "00:00:00");
});

test("S-07 label：見出しの形（第N部（開始〜終了））", () => {
  assert.equal(C.label({ index: 1, offset: 600, duration: 600 }), "第2部（00:10:00〜00:20:00）");
});

test("S-08 wavBytes と maxSecondsForLimit：本の数字と一致する（1分 ≒ 1.9 MB、25 MB ≒ 781 秒）", () => {
  assert.equal(C.wavBytes(60, 16000, 1, 16), 44 + 1920000);
  assert.equal(C.maxSecondsForLimit(25, 16000, 1, 16), 781);
  assert.ok(Number.isNaN(C.wavBytes(-1, 16000, 1, 16)));
});
