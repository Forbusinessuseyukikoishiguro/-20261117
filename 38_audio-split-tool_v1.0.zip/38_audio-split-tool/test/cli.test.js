const test = require("node:test");
const assert = require("node:assert/strict");
const { spawnSync } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const CLI = path.join(__dirname, "..", "cli", "split.js");
const run = (...a) => spawnSync("node", [CLI, ...a], { encoding: "utf8" });

test("L-01 plan：区間の一覧を、見出し付きで出す", () => {
  const r = run("plan", "--seconds", "3725", "--seg", "600");
  assert.equal(r.status, 0);
  assert.match(r.stdout, /区間の数 7/);
  assert.match(r.stdout, /第7部（01:00:00〜01:02:05）/);
});

test("L-02 plan：不正な値は、区間を作らず、理由を出す", () => {
  const r = run("plan", "--seconds", "0", "--seg", "600");
  assert.equal(r.status, 2);
  assert.match(r.stdout, /0 より大きい数/);
});

test("L-03 limit：25 MB の上限を、秒数で示す", () => {
  const r = run("limit", "--mb", "25");
  assert.match(r.stdout, /781 秒/);
});

test("L-04 wav：WAV を分け、出力フォルダに書き出す", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "cli-"));
  const input = path.join(dir, "in.wav");
  const W = require("../cli/wav-split.js");
  const data = Buffer.alloc(16000 * 2 * 4);
  fs.writeFileSync(input, Buffer.concat([W.header(data.length, { format: 1, channels: 1, rate: 16000, blockAlign: 2, bits: 16 }), data]));
  const r = run("wav", input, path.join(dir, "pieces"), "--seg", "2");
  assert.equal(r.status, 0);
  assert.equal(fs.readdirSync(path.join(dir, "pieces")).length, 2);
});
