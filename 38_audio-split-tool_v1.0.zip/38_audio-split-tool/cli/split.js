#!/usr/bin/env node
/* split.js — 音声の区間計算・サイズの目安・WAV の分割
 *   node cli/split.js plan --seconds 3725 --seg 600          区間の一覧
 *   node cli/split.js size --seconds 600 [--rate 16000 --channels 1 --bits 16]   WAV の大きさ
 *   node cli/split.js limit --mb 25 [--rate 16000]           上限に入る最長の秒数
 *   node cli/split.js wav <入力.wav> <出力フォルダ> --seg 600   WAV を分ける */
"use strict";
// パイプで途中まで読まれたとき（例：| head）に、エラーの表示を出さずに終わる
process.stdout.on("error", (e) => { if (e.code === "EPIPE") process.exit(0); });
const C = require("../core/split-core.js");
const { splitWavFile } = require("./wav-split.js");

function opts(args) {
  const o = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith("--")) { o[args[i].slice(2)] = args[i + 1]; i++; }
    else (o._ = o._ || []).push(args[i]);
  }
  return o;
}
const num = (v, d) => (v === undefined ? d : Number(v));

function main(argv) {
  const [cmd, ...rest] = argv;
  const o = opts(rest);
  const out = (s) => process.stdout.write(s + "\n");
  switch (cmd) {
    case "plan": {
      const segs = C.segments(num(o.seconds), num(o.seg));
      if (!segs.length) { out("全長と分割単位は、0 より大きい数で入れてください。"); return 2; }
      out(`全長 ${C.fmtTime(num(o.seconds))}、分割単位 ${C.fmtTime(num(o.seg))}、区間の数 ${segs.length}`);
      for (const s of segs) out(`  ${C.label(s)}  長さ ${s.duration.toFixed(1)} 秒`);
      return 0;
    }
    case "size": {
      const b = C.wavBytes(num(o.seconds), num(o.rate, 16000), num(o.channels, 1), num(o.bits, 16));
      if (!Number.isFinite(b)) { out("秒数・周波数・チャンネル・ビット数を、正しく入れてください。"); return 2; }
      out(`WAV の大きさ：${C.fmtMB(b)}（${b} バイト）`); return 0;
    }
    case "limit": {
      const s = C.maxSecondsForLimit(num(o.mb), num(o.rate, 16000), num(o.channels, 1), num(o.bits, 16));
      if (!Number.isFinite(s)) { out("上限（MB）と、音声の形式を正しく入れてください。"); return 2; }
      out(`${o.mb} MB に入る WAV の最長：${s} 秒（約 ${(s / 60).toFixed(1)} 分）`); return 0;
    }
    case "wav": {
      const [inPath, outDir] = o._ || [];
      if (!inPath || !outDir) { out("使い方：wav <入力.wav> <出力フォルダ> --seg 600"); return 2; }
      try {
        const files = splitWavFile(inPath, outDir, num(o.seg, 600));
        for (const f of files) out(`${f.file}（${f.seconds.toFixed(1)} 秒）`);
        out(`${files.length} 個に分けました。`); return 0;
      } catch (e) { out("分けられませんでした：" + e.message); return 1; }
    }
    default:
      out("使い方：plan | size | limit | wav（--help は、ファイル先頭の説明を参照）"); return 2;
  }
}
if (require.main === module) process.exitCode = main(process.argv.slice(2));
module.exports = { main };
