/* wav-split.js — PCM の WAV を、指定の秒数ごとに分ける（外部の道具は使わない）
 * 対応：PCM（形式コード 1）、16bit、チャンネル数は任意。ほかの形式は、理由を出して止める。 */
"use strict";
const fs = require("fs");

function readWav(buf) {
  if (buf.length < 44 || buf.toString("ascii", 0, 4) !== "RIFF" || buf.toString("ascii", 8, 12) !== "WAVE") {
    throw new Error("WAV ファイルではありません（RIFF・WAVE の印が無い）");
  }
  let pos = 12, fmt = null, data = null;
  while (pos + 8 <= buf.length) {
    const id = buf.toString("ascii", pos, pos + 4);
    const size = buf.readUInt32LE(pos + 4);
    const body = pos + 8;
    if (id === "fmt ") {
      fmt = {
        format: buf.readUInt16LE(body), channels: buf.readUInt16LE(body + 2),
        rate: buf.readUInt32LE(body + 4), blockAlign: buf.readUInt16LE(body + 12), bits: buf.readUInt16LE(body + 14),
      };
    } else if (id === "data") {
      data = buf.subarray(body, Math.min(buf.length, body + size));
    }
    pos = body + size + (size % 2);
  }
  if (!fmt) throw new Error("fmt の情報が見つかりません");
  if (!data) throw new Error("data（音声の中身）が見つかりません");
  if (fmt.format !== 1) throw new Error(`PCM（形式 1）ではありません（形式 ${fmt.format}）。この道具は PCM の WAV だけ扱います`);
  if (fmt.bits !== 16) throw new Error(`16bit ではありません（${fmt.bits}bit）`);
  return { fmt, data };
}

function header(dataBytes, fmt) {
  const h = Buffer.alloc(44);
  h.write("RIFF", 0, "ascii"); h.writeUInt32LE(36 + dataBytes, 4); h.write("WAVE", 8, "ascii");
  h.write("fmt ", 12, "ascii"); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20);
  h.writeUInt16LE(fmt.channels, 22); h.writeUInt32LE(fmt.rate, 24);
  h.writeUInt32LE(fmt.rate * fmt.blockAlign, 28); h.writeUInt16LE(fmt.blockAlign, 32); h.writeUInt16LE(fmt.bits, 34);
  h.write("data", 36, "ascii"); h.writeUInt32LE(dataBytes, 40);
  return h;
}

/** 分割して、ファイルの一覧（パスと秒数）を返す */
function splitWavFile(inPath, outDir, segSec) {
  const { fmt, data } = readWav(fs.readFileSync(inPath));
  const frame = fmt.blockAlign;
  const framesPerSeg = Math.round(segSec * fmt.rate);
  if (!(framesPerSeg > 0)) throw new Error("分割の秒数が正しくありません");
  const totalFrames = Math.floor(data.length / frame);
  fs.mkdirSync(outDir, { recursive: true });
  const outs = [];
  for (let start = 0, i = 1; start < totalFrames; start += framesPerSeg, i++) {
    const frames = Math.min(framesPerSeg, totalFrames - start);
    const chunk = data.subarray(start * frame, (start + frames) * frame);
    const file = `${outDir}/piece-${String(i).padStart(2, "0")}.wav`;
    fs.writeFileSync(file, Buffer.concat([header(chunk.length, fmt), chunk]));
    outs.push({ file, seconds: frames / fmt.rate });
  }
  return outs;
}

module.exports = { readWav, header, splitWavFile };
