#!/usr/bin/env node
/* navi.js — つづけるナビ（コマンド版）
 * 使い方：
 *   node cli/navi.js status              いまの進み具合と、次にやること
 *   node cli/navi.js next                次にやること（1つだけ）
 *   node cli/navi.js done <手順の id>     手順を終えたと記録する
 *   node cli/navi.js undo <手順の id>     記録を取り消す
 *   node cli/navi.js hint "<エラーの文字>"  エラーの文字から、直し方を探す
 *   node cli/navi.js check [--kit <フォルダ>]  環境と、キットの試験を確かめる
 *   node cli/navi.js reset               記録を消す（確認つき）
 * 記録の場所：環境変数 NAVI_PROGRESS、無ければ ~/.tsuzukeru-progress.json */
"use strict";
const fs = require("fs");
const os = require("os");
const path = require("path");
const { execSync } = require("child_process");
const C = require("../core/navi-core.js");

const FILE = process.env.NAVI_PROGRESS || path.join(os.homedir(), ".tsuzukeru-progress.json");

function load() {
  try { return JSON.parse(fs.readFileSync(FILE, "utf8")).done || []; } catch { return []; }
}
function save(done) {
  fs.writeFileSync(FILE, JSON.stringify({ done: [...new Set(done)], updated: new Date().toISOString() }, null, 2), "utf8");
}
function out(s) { process.stdout.write(s + "\n"); }

function status(done) {
  const p = C.progress(done);
  const bar = "■".repeat(Math.round(p.percent / 5)).padEnd(20, "□");
  out(`進み具合：${bar} ${p.finished} / ${p.total}（${p.percent}%）`);
  out(C.encouragement(done));
  out("");
  for (const r of C.listSteps(done)) out(`${r.done ? "✅" : "⬜"} ${String(r.no).padStart(2)}. ${r.title}`);
  out("");
  const n = C.nextStep(done);
  out(n ? `次にやること：${n.title}（ID：${n.id}）\n「できた！」の目安：${n.done}` : "全部終わりました。おめでとうございます。");
}

function check(args) {
  const i = args.indexOf("--kit");
  const kit = i >= 0 ? args[i + 1] : null;
  const rows = [];
  const major = Number(process.versions.node.split(".")[0]);
  rows.push([major >= 18, `Node.js ${process.versions.node}（18 以上）`, major >= 18 ? "" : "nvm で 22 を入れる"]);
  let py = false;
  try { execSync("python3 --version", { stdio: "pipe" }); py = true; } catch {}
  rows.push([py, "Python 3（画面の試験で使う。任意）", py ? "" : "sudo apt-get install -y python3"]);
  if (kit) {
    let ok = false, detail = "";
    try {
      const res = execSync("npm test", { cwd: kit, stdio: "pipe", encoding: "utf8" });
      ok = /# fail 0/.test(res);
      detail = (res.match(/# pass \d+/) || ["# pass ?"])[0];
    } catch (e) {
      detail = String(e.stdout || e.message).slice(0, 200);
    }
    rows.push([ok, `キットの試験（${kit}）：${detail}`, ok ? "" : "出力のエラーを、hint コマンドに貼って確かめる"]);
  }
  let allOk = true;
  for (const [ok, label, fix] of rows) {
    out(`${ok ? "✅" : "❌"} ${label}`);
    if (!ok) { allOk = false; if (fix) out(`   → 直し方：${fix}`); }
  }
  out(allOk ? "\n準備は、ととのっています。次に進みましょう。" : "\n少しだけ、直すところがあります。焦らなくて大丈夫です。一つずつ直せば進めます。");
  return allOk ? 0 : 1;
}

function main(argv) {
  const [cmd, ...rest] = argv;
  const done = load();
  switch (cmd) {
    case "status": case undefined: status(done); return 0;
    case "next": { const n = C.nextStep(done); out(n ? `${n.title}（ID：${n.id}）` : "全部終わりました。"); return 0; }
    case "done": {
      const id = rest[0];
      if (!C.STEPS.some((s) => s.id === id)) { out(`手順の ID が違います：${id}（一覧は status で見られます）`); return 2; }
      save([...done, id]); out(`記録しました：${id}`); out(C.encouragement([...done, id])); return 0;
    }
    case "undo": { const id = rest[0]; save(done.filter((x) => x !== id)); out(`取り消しました：${id}`); return 0; }
    case "hint": {
      const text = rest.join(" ") || fs.readFileSync(0, "utf8");
      const h = C.matchHint(text);
      if (!h) { out("エラーの文字を、hint の後ろに書いてください。"); return 2; }
      out(`原因の候補：${h.cause}`); out(`直し方：${h.fix}`);
      if (h.step) out(`戻る手順：${h.step}（status で、その手順を確かめられます）`);
      out("\n落ち着いて、一つずつ試してください。うまくいかなくても、それは次のヒントの材料です。");
      return 0;
    }
    case "check": return check(rest);
    case "reset": {
      if (!rest.includes("--yes")) { out("記録を消すには、reset --yes と入力してください。"); return 2; }
      save([]); out("記録を消しました。最初から始められます。"); return 0;
    }
    default: out(__doc_usage()); return 2;
  }
}
function __doc_usage() { return "使い方：status | next | done <id> | undo <id> | hint \"<エラーの文字>\" | check [--kit <フォルダ>] | reset --yes"; }

if (require.main === module) process.exitCode = main(process.argv.slice(2));
module.exports = { main, FILE };
