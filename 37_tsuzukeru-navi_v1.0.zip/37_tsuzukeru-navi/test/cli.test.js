const test = require("node:test");
const assert = require("node:assert/strict");
const { execFileSync, spawnSync } = require("node:child_process");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const NAVI = path.join(__dirname, "..", "cli", "navi.js");
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "navi-"));
const env = Object.assign({}, process.env, { NAVI_PROGRESS: path.join(tmp, "p.json") });
const run = (...a) => spawnSync("node", [NAVI, ...a], { env, encoding: "utf8" });

test("C-01 done：手順を記録し、次にやることが進む", () => {
  assert.equal(run("done", "node").status, 0);
  const out = run("next").stdout;
  assert.match(out, /VS Code/);
  assert.match(out, /ID：vscode/);
});

test("C-02 done：知らない手順の ID は、記録せずに案内する", () => {
  const r = run("done", "no-such-step");
  assert.equal(r.status, 2);
  assert.match(r.stdout, /ID が違います/);
});

test("C-03 hint：エラーの文字から、直し方を出す", () => {
  const r = run("hint", "Error: listen EADDRINUSE: address already in use");
  assert.equal(r.status, 0);
  assert.match(r.stdout, /直し方：前のターミナル/);
});

test("C-04 hint：パイプでも受け取れる", () => {
  const r = spawnSync("node", [NAVI, "hint"], { env, input: "bash: node: command not found\n", encoding: "utf8" });
  assert.match(r.stdout, /道具が入っていない/);
});

test("C-05 reset：確認なしでは消さない。--yes で消す", () => {
  assert.equal(run("reset").status, 2);
  assert.match(fs.readFileSync(path.join(tmp, "p.json"), "utf8"), /node/);
  assert.equal(run("reset", "--yes").status, 0);
  assert.match(run("status").stdout, /0 \/ 12/);
});

test("C-06 check：Node.js の確認は必ず行われ、結果を ✅ か ❌ で示す", () => {
  const r = run("check");
  assert.match(r.stdout, /Node\.js/);
  assert.match(r.stdout, /[✅❌]/);
});
