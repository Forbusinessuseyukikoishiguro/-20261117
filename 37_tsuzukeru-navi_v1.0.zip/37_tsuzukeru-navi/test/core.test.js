const test = require("node:test");
const assert = require("node:assert/strict");
const C = require("../core/navi-core.js");

test("N-01 progress：完了の数と、割合を正しく出す", () => {
  assert.deepEqual(C.progress([]), { finished: 0, total: 12, percent: 0 });
  assert.equal(C.progress(["node", "vscode"]).finished, 2);
  assert.equal(C.progress(C.STEPS.map((s) => s.id)).percent, 100);
});

test("N-02 nextStep：いつも1つだけ、最初の未完了を返す。全部終われば null", () => {
  assert.equal(C.nextStep([]).id, "node");
  assert.equal(C.nextStep(["node"]).id, "vscode");
  assert.equal(C.nextStep(["node", "first-test"]).id, "vscode", "途中を飛ばしても、未完了の最初を示す");
  assert.equal(C.nextStep(C.STEPS.map((s) => s.id)), null);
});

test("N-03 matchHint：エラーの文字から、直し方を探す（大文字小文字を区別しない）", () => {
  assert.equal(C.matchHint("Error: listen EADDRINUSE: address already in use :::8790").step, "mock");
  assert.equal(C.matchHint("Access to fetch ... has been blocked by CORS policy").step, "e2e");
  assert.equal(C.matchHint("bash: node: command not found").step, "node");
  assert.equal(C.matchHint("ENOENT: no such file or directory").step, "first-test");
});

test("N-04 matchHint：知らない文字でも、見捨てず、次の行動を示す", () => {
  const h = C.matchHint("予想しないこと");
  assert.ok(h.fix.length > 0);
  assert.equal(C.matchHint(""), null);
});

test("N-05 encouragement：責めず、いつも次の一歩に向かう言葉を返す", () => {
  assert.match(C.encouragement([]), /最初の一歩/);
  assert.match(C.encouragement(C.STEPS.map((s) => s.id)), /全部終わりました/);
  assert.match(C.encouragement(["node", "vscode", "first-test", "spec", "html", "css", "lib"]), /半分を越えました/);
});

test("N-06 listSteps：12手順の状態を、番号つきで返す", () => {
  const rows = C.listSteps(["node"]);
  assert.equal(rows.length, 12);
  assert.equal(rows[0].done, true);
  assert.equal(rows[1].done, false);
  assert.equal(rows[0].no, 1);
});
