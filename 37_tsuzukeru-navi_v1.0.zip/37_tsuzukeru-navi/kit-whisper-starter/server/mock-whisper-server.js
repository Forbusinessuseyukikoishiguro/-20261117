/* ============================================================================
 * mock-whisper-server.js — 文字起こし API の模倣サーバー（APIキー不要・課金なし）
 * ----------------------------------------------------------------------------
 * 起動：node server/mock-whisper-server.js          （既定：localhost:8790）
 * 形：POST /v1/audio/transcriptions（multipart/form-data。項目 file と model）
 *     応答 {"text": "..."}。認証は Authorization: Bearer test-key
 * 失敗の再現：環境変数 FAIL_EVERY=n で、n 回目ごとに 429（0 なら起こさない）
 * 注意：本物ではない。音声を解析せず、受け取った大きさと名前から文字を作るだけ。
 *       本物の API の細部は、公式ドキュメントで確かめること。
 * ============================================================================ */
"use strict";
const http = require("http");

const PORT = Number(process.env.PORT || 8790);
const KEY = "test-key";
const MAX_BYTES = 25 * 1024 * 1024;     // 公式が案内する上限（25 MB）
const FAIL_EVERY = Number(process.env.FAIL_EVERY || 0);
let count = 0;

// CORS：別のポート（画面）から直接呼ぶための応答。ブラウザは、事前の確認（OPTIONS）に答えないと送らない
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Authorization, Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Content-Length": Buffer.byteLength(body), ...CORS });
  res.end(body);
}

function handle(req, res, raw) {
  if (req.method === "OPTIONS") { res.writeHead(204, CORS); return res.end(); }
  if (req.method !== "POST" || req.url !== "/v1/audio/transcriptions") return send(res, 404, { error: { message: "not found" } });
  const auth = req.headers["authorization"] || "";
  if (auth !== `Bearer ${KEY}`) return send(res, 401, { error: { message: "APIキーが正しくありません" } });
  const ct = req.headers["content-type"] || "";
  const m = ct.match(/boundary=(.+)$/);
  if (!/multipart\/form-data/.test(ct) || !m) return send(res, 400, { error: { message: "multipart/form-data で送ってください" } });
  if (raw.length > MAX_BYTES) return send(res, 413, { error: { message: "ファイルが大きすぎます（25 MB まで）" } });

  // 項目の確認（file と model が必要）。バイト列を文字として見て、名前の有無を調べる
  const text = raw.toString("latin1");
  const hasFile = /name="file"; filename="([^"]*)"/.exec(text);
  const hasModel = /name="model"/.test(text);
  if (!hasFile) return send(res, 400, { error: { message: "file が必要です" } });
  if (!hasModel) return send(res, 400, { error: { message: "model が必要です" } });

  count += 1;
  if (FAIL_EVERY && count % FAIL_EVERY === 0) return send(res, 429, { error: { message: "利用の上限（模倣）" } });
  const name = Buffer.from(hasFile[1], "latin1").toString("utf8");
  send(res, 200, { text: `【モック】${name}（${raw.length} バイト）の文字起こし結果です。` });
}

const server = http.createServer((req, res) => {
  const chunks = [];
  req.on("data", (c) => chunks.push(c));
  req.on("end", () => handle(req, res, Buffer.concat(chunks)));
});

module.exports = { server };

if (require.main === module) {
  server.listen(PORT, () => console.log(`mock whisper server: http://localhost:${PORT}/v1/audio/transcriptions（失敗の再現：FAIL_EVERY=${FAIL_EVERY}）`));
}
