/* server.test.js — 模倣サーバーの試験（実際に送って確かめる）。APIキーは test-key。 */
const test = require("node:test");
const assert = require("node:assert/strict");
const { server } = require("../server/mock-whisper-server.js");

let base;
test.before(() => new Promise((ok) => server.listen(0, "127.0.0.1", () => { base = `http://127.0.0.1:${server.address().port}`; ok(); })));
test.after(() => new Promise((ok) => server.close(ok)));

function form(bytes, name = "a.wav", withFile = true, withModel = true) {
  const fd = new FormData();
  if (withFile) fd.append("file", new Blob([bytes], { type: "audio/wav" }), name);
  if (withModel) fd.append("model", "whisper-1");
  return fd;
}
const post = (fd, auth = "Bearer test-key") =>
  fetch(`${base}/v1/audio/transcriptions`, { method: "POST", headers: auth ? { Authorization: auth } : {}, body: fd });

test("S-01 正しいキーと、file と model を送ると、text を含む 200 が返る", async () => {
  const res = await post(form(new Uint8Array(1000), "会議.wav"));
  assert.equal(res.status, 200);
  const data = await res.json();
  assert.equal(typeof data.text, "string");
  assert.match(data.text, /会議\.wav/);
});

test("S-02 キーが違うと 401、キーが無くても 401", async () => {
  assert.equal((await post(form(new Uint8Array(10)), "Bearer wrong")).status, 401);
  assert.equal((await post(form(new Uint8Array(10)), "")).status, 401);
});

test("S-03 file が無い、model が無いと 400", async () => {
  assert.equal((await post(form(new Uint8Array(10), "a.wav", false, true))).status, 400);
  assert.equal((await post(form(new Uint8Array(10), "a.wav", true, false))).status, 400);
});

test("S-04 25 MB を超えると 413（送信の上限）", async () => {
  const big = new Uint8Array(26 * 1024 * 1024);
  assert.equal((await post(form(big))).status, 413);
});

test("S-05 違う経路は 404", async () => {
  const res = await fetch(`${base}/v1/chat/completions`, { method: "POST", headers: { Authorization: "Bearer test-key" }, body: form(new Uint8Array(10)) });
  assert.equal(res.status, 404);
});

test("S-06 事前の確認（OPTIONS）に答え、CORS の許可を返す（画面から直接呼ぶため）", async () => {
  const res = await fetch(`${base}/v1/audio/transcriptions`, { method: "OPTIONS", headers: { Origin: "http://localhost:8000", "Access-Control-Request-Method": "POST" } });
  assert.equal(res.status, 204);
  assert.match(res.headers.get("access-control-allow-headers") || "", /Authorization/);
});
