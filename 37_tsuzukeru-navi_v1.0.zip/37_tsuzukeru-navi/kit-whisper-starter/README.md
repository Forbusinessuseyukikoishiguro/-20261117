# はじめての文字起こしツール（Whisper 形式）

## 中身
| ファイル | 役割 |
|---|---|
| web/index.html、style.css | 画面（部品と見た目） |
| web/app.js | 画面の動き（送信、表示、保存） |
| web/lib.js | 計算（ファイルの検査、エラーの文言、保存名。画面に触らない） |
| web/config.example.js | 設定の雛形（config.js にコピーして使う） |
| server/mock-whisper-server.js | 練習用の模倣サーバー（APIキー不要） |
| test/ | 試験（npm test） |

## すぐ試す（練習：APIキー不要）
```bash
npm test                       # 試験（12件）
npm run mock                   # 模倣サーバーを起動（別の端末に残す）
cp web/config.example.js web/config.js
# 画面を開く：python3 -m http.server 8000 を web の中で実行し、http://localhost:8000/ を開く
```

## 注意
- 本物の API（OpenAI など）は、この一式では確かめていない。使う前に、公式ドキュメントで接続先、項目名、料金、モデル名を確かめる
- APIキーは config.js にだけ書き、共有・Git に入れない（.gitignore で除外）
