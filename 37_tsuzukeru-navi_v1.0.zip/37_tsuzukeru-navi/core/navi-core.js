/* navi-core.js — 「つづけるナビ」の計算（画面にもコマンドにも依存しない）。
 * ブラウザでは window.TsuzukeruCore、Node.js では require で使う。
 * 挫折させないための考え方：
 *  - 次にやることは、いつも1つだけ示す（迷わせない）
 *  - 小さな「できた」を、必ず記録して見せる
 *  - 失敗したら、責めずに、原因の候補と直し方を示す */
(function (root) {
  "use strict";

  /** 学習の手順（順番どおり） */
  const STEPS = [
    { id: "node",      title: "Node.js 22 を入れる",                 done: "node -v が v22 で始まる" },
    { id: "vscode",    title: "VS Code を入れて、フォルダを開く",       done: "code . で、プロジェクトが開く" },
    { id: "first-test",title: "最初の試験を動かす（npm test）",          done: "# pass 13、# fail 0" },
    { id: "spec",      title: "依頼を、5つの問いで仕様にする",           done: "FR・AC の表が書けた" },
    { id: "html",      title: "HTML：部品と id を見つける",              done: "id=\"run\" を指させる" },
    { id: "css",       title: "CSS：色の変数を変えて、元に戻す",         done: "ボタンの色が変わり、戻せた" },
    { id: "lib",       title: "lib.js（計算）を読む",                    done: "checkFile の順番を説明できる" },
    { id: "check-file",title: "上限を変えて、W-01 が落ちるのを見る",    done: "落ちる理由を説明できた" },
    { id: "mock",      title: "模倣サーバーを起動し、キーを確かめる",    done: "キーありは 200、なしは 401" },
    { id: "e2e",       title: "画面の試験（7件）を通す",                done: "合格 7 / 7" },
    { id: "add-test",  title: "テストを1つ追加する（W-08）",            done: "# pass 14" },
    { id: "next",      title: "次に作るものを、仕様にする",              done: "次の依頼を、5つの問いで答えた" },
  ];

  /** 直し方の表：エラーの文字の一部 → 原因の候補と、直し方 */
  const HINTS = [
    { match: ["command not found", "内部コマンドまたは外部コマンド", "見つかりません"], cause: "道具が入っていない、またはターミナルを開き直していない", fix: "道具を入れ直し、ターミナルを開き直す（Node.js は nvm で 22 を入れる）", step: "node" },
    { match: ["EADDRINUSE", "Address already in use"], cause: "同じ番号の窓口（ポート）が、前の作業で使われたまま", fix: "前のターミナルで Ctrl + C を押して、止める", step: "mock" },
    { match: ["CORS", "blocked by CORS"], cause: "画面と窓口の間の、事前の確認（OPTIONS）に答えていない", fix: "窓口が、OPTIONS に 204 で答えているか確かめる。F12 の Console を見る", step: "e2e" },
    { match: ["401", "APIキーが正しくありません"], cause: "キーが違う、または無い（練習は test-key）", fix: "config.js の apiKey が test-key か確かめる", step: "mock" },
    { match: ["大きすぎ", "413"], cause: "ファイルが 25 MB を超えている", fix: "短く分けてから送る（この講座では 2 分程度の音声）", step: "check-file" },
    { match: ["not ok"], cause: "試験が、仕様と違う結果になった", fix: "落ちた試験の名前（番号）を見て、対応する仕様を読む", step: "first-test" },
    { match: ["ENOENT", "No such file or directory"], cause: "フォルダや、ファイルの場所が違う", fix: "pwd で今の場所を確かめ、cd で移動し直す", step: "first-test" },
    { match: ["Cannot connect to the Docker daemon"], cause: "Docker Desktop が起動していない", fix: "Docker Desktop を起動し、Running になるまで待つ", step: "vscode" },
    { match: ["Executable doesn't exist", "playwright install"], cause: "ブラウザが入っていない", fix: "python -m playwright install --with-deps chromium を実行する", step: "e2e" },
    { match: ["EACCES", "Permission denied"], cause: "権限が足りない、またはファイルの持ち主が違う", fix: "sudo が必要か確かめる。ファイルの場所を、自分のフォルダ（~）に移す", step: "vscode" },
  ];

  /** 進み具合（done は、完了した手順の id の配列） */
  function progress(done) {
    const set = new Set(done || []);
    const finished = STEPS.filter((s) => set.has(s.id)).length;
    return { finished, total: STEPS.length, percent: Math.round((finished / STEPS.length) * 100) };
  }

  /** 次にやること（完了していない最初の手順）。すべて終わったら null */
  function nextStep(done) {
    const set = new Set(done || []);
    return STEPS.find((s) => !set.has(s.id)) || null;
  }

  /** エラーの文字から、直し方を探す。最初に当たったものを返す */
  function matchHint(text) {
    const t = String(text || "");
    if (!t.trim()) return null;
    const lower = t.toLowerCase();
    for (const h of HINTS) {
      if (h.match.some((m) => lower.includes(m.toLowerCase()))) return h;
    }
    return { match: [], cause: "この文字からは、原因を特定できなかった", fix: "エラーの文字をそのまま書き出し、F12 の Console か、ターミナルの前の行を確かめる", step: null };
  }

  /** 励ましの言葉（進み具合に合わせて、一つ選ぶ）。責める言葉は使わない */
  function encouragement(done) {
    const p = progress(done);
    if (p.finished === 0) return "最初の一歩です。Node.js を入れるところから、始めましょう。";
    if (p.finished === p.total) return "全部終わりました。作ったものを、自分の言葉で説明してみましょう。";
    if (p.percent >= 50) return `半分を越えました（${p.finished} / ${p.total}）。ここまで来た人は、最後まで行けます。`;
    return `${p.finished} つ終わりました。小さな「できた」を、積み重ねています。`;
  }

  /** 手順の状態を、一覧にする（画面やコマンドで表示する用） */
  function listSteps(done) {
    const set = new Set(done || []);
    return STEPS.map((s, i) => ({ no: i + 1, id: s.id, title: s.title, done: set.has(s.id), check: s.done }));
  }

  const api = { STEPS, HINTS, progress, nextStep, matchHint, encouragement, listSteps };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.TsuzukeruCore = api;
})(typeof window !== "undefined" ? window : globalThis);
